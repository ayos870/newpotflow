import React from 'react';
import { CloseIcon, BellIcon } from './IconComponents';

interface AnnouncementBannerProps {
  message: string;
  onDismiss: () => void;
}

const AnnouncementBanner: React.FC<AnnouncementBannerProps> = ({ message, onDismiss }) => {
  return (
    <div className="bg-brand-cyan text-brand-dark p-3 sticky top-0 z-50 animate-fade-in-down">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BellIcon className="w-6 h-6" />
          <p className="font-semibold text-sm">{message}</p>
        </div>
        <button
          onClick={onDismiss}
          className="p-1 rounded-full hover:bg-black/10 transition-colors"
          aria-label="Dismiss announcement"
        >
          <CloseIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default AnnouncementBanner;
