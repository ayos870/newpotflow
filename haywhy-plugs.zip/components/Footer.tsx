import React from 'react';
import { MailIcon, WhatsAppIcon } from './IconComponents';

interface FooterProps {
    onShowTerms: () => void;
}

const Footer: React.FC<FooterProps> = ({ onShowTerms }) => {
  return (
    <footer className="bg-white dark:bg-brand-light-dark/50 border-t border-gray-200 dark:border-brand-slate/50 mt-auto">
      <div className="container mx-auto px-4 py-6 md:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
            <span>© {new Date().getFullYear()} HAYWHY PLUGS. All rights reserved.</span>
            <span className="hidden sm:inline">|</span>
            <button onClick={onShowTerms} className="hover:text-brand-cyan transition-colors underline sm:no-underline">Terms of Service</button>
        </div>
        <div className="flex items-center gap-2">
            <a 
              href="https://wa.me/2348168286821?text=Hello%20Admin%2C%20I%20need%20help"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-500 text-white font-bold py-2 px-4 rounded-md hover:bg-green-600 transition-all duration-300 text-sm"
            >
              <WhatsAppIcon className="w-4 h-4" />
              Contact on WhatsApp
            </a>
            <a 
              href="mailto:admin@socialswap.com"
              className="flex items-center gap-2 bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300 text-sm"
            >
              <MailIcon className="w-4 h-4" />
              Contact by Email
            </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;