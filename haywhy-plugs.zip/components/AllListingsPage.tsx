import React from 'react';
import { Listing, User } from '../types';
import AccountCard from './AccountCard';
import { ArrowLeftIcon } from './IconComponents';

interface AllListingsPageProps {
  listings: Listing[];
  onBack: () => void;
  onViewDetails: (account: Listing) => void;
  currentUser: User | null;
}

const AllListingsPage: React.FC<AllListingsPageProps> = ({ listings, onBack, onViewDetails, currentUser }) => {
  return (
    <div className="container mx-auto p-4 md:p-8 animate-fade-in">
      <div className="flex justify-between items-center mb-6 border-b-2 border-gray-200 dark:border-brand-slate pb-4">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">All Available Accounts</h1>
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          Back to Dashboard
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listings.map(account => (
          <AccountCard 
            key={account.id} 
            account={account} 
            onViewDetails={onViewDetails}
            currentUser={currentUser}
            isOwner={currentUser?.username === account.sellerUsername}
          />
        ))}
      </div>

      {listings.length === 0 && (
          <div className="col-span-1 md:col-span-3 text-center py-12 bg-white dark:bg-brand-light-dark rounded-lg shadow-inner">
              <p className="text-gray-500 dark:text-gray-400">
                  No accounts available at the moment. Check back soon!
              </p>
          </div>
      )}
    </div>
  );
};

export default AllListingsPage;
