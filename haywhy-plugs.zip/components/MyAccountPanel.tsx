import React, { useState } from 'react';
import { SiteUser, Listing, Payment, PurchaseStatus, AccountPurchase } from '../types';
import { SaveIcon, TrashIcon } from './IconComponents';

interface MyAccountPanelProps {
    currentUser: SiteUser;
    listings: Listing[];
    payments: Payment[];
    purchases: AccountPurchase[];
    onUpdateUser: (updatedDetails: Partial<SiteUser>) => string | void;
    onDeleteListing: (id: string) => void;
    onDeleteCurrentUser: () => void;
}

type MyAccountTab = 'profile' | 'listings' | 'purchases' | 'funding';

const MyAccountPanel: React.FC<MyAccountPanelProps> = ({ currentUser, listings, payments, purchases, onUpdateUser, onDeleteListing, onDeleteCurrentUser }) => {
    const [activeTab, setActiveTab] = useState<MyAccountTab>('profile');
    const [username, setUsername] = useState(currentUser.username);
    const [email, setEmail] = useState(currentUser.email);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');

    const handleProfileUpdate = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (password && password !== confirmPassword) {
            setError("Passwords do not match.");
            return;
        }

        const updates: Partial<SiteUser> = {};
        if (username !== currentUser.username) {
            updates.username = username;
        }
        if (email !== currentUser.email) {
            updates.email = email;
        }
        if (password) {
            updates.password = password;
        }

        if (Object.keys(updates).length > 0) {
            const errorMsg = onUpdateUser(updates);
            if(errorMsg) {
                setError(errorMsg);
            } else {
                // Success message is now handled by the global notification system
                setPassword('');
                setConfirmPassword('');
            }
        } else {
            setError("No changes to save.");
        }
    };
    
    const handleDeleteAccount = () => {
        if (window.confirm('Are you absolutely sure? This will permanently delete your account and all of your listings. This action cannot be undone.')) {
            onDeleteCurrentUser();
        }
    };
    
    const getStatusBadge = (status: PurchaseStatus) => {
        switch(status) {
            case PurchaseStatus.Completed: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
            case PurchaseStatus.Pending: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
            case PurchaseStatus.Failed: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
        }
    };
    
    const TabButton: React.FC<{ tab: MyAccountTab, label: string, count?: number }> = ({ tab, label, count }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-bold transition-colors rounded-t-lg flex items-center gap-2 ${
                activeTab === tab
                ? 'text-brand-cyan border-b-2 border-brand-cyan'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
            }`}
        >
            {label}
            {typeof count !== 'undefined' && (
                <span className={`px-2 py-0.5 rounded-full text-xs ${activeTab === tab ? 'bg-brand-cyan text-brand-dark' : 'bg-gray-200 dark:bg-brand-slate text-gray-600 dark:text-gray-300'}`}>{count}</span>
            )}
        </button>
    );

    return (
        <div className="space-y-8">
            <div className="bg-white dark:bg-brand-light-dark p-6 rounded-lg shadow-2xl border border-gray-200 dark:border-brand-slate">
                <div className="flex border-b-2 border-gray-200 dark:border-brand-slate mb-6">
                    <TabButton tab="profile" label="Profile" />
                    <TabButton tab="listings" label="My Listings" count={listings.length} />
                    <TabButton tab="purchases" label="Purchase History" count={purchases.length} />
                    <TabButton tab="funding" label="Funding History" count={payments.length} />
                </div>

                {activeTab === 'profile' && (
                    <div>
                        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">My Profile</h2>
                        <div className="mb-6">
                            <div className="bg-gray-50 dark:bg-brand-slate/50 p-4 rounded-lg inline-block">
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Wallet Balance</p>
                                <p className="text-lg font-semibold text-brand-cyan">₦{currentUser.walletBalance.toLocaleString()}</p>
                            </div>
                        </div>
                        <form onSubmit={handleProfileUpdate} className="space-y-4">
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="username-profile" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Username</label>
                                    <input id="username-profile" type="text" value={username} onChange={(e) => setUsername(e.target.value)} required className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan" />
                                </div>
                                <div>
                                    <label htmlFor="email-profile" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Email Address</label>
                                    <input id="email-profile" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan" />
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="password-profile" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">New Password (optional)</label>
                                    <input id="password-profile" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan" />
                                </div>
                                <div>
                                    <label htmlFor="confirm-password-profile" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Confirm New Password</label>
                                    <input id="confirm-password-profile" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="••••••••" className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan" />
                                </div>
                            </div>
                            {error && <p className="text-red-500 dark:text-red-400 text-sm">{error}</p>}
                            <div className="pt-2">
                                <button type="submit" className="inline-flex items-center gap-2 bg-brand-cyan text-brand-dark font-bold py-2.5 px-6 rounded-md hover:bg-cyan-400 transition-all duration-300">
                                <SaveIcon className="w-5 h-5" />
                                    Save Changes
                                </button>
                            </div>
                        </form>

                        <div className="mt-8 pt-6 border-t-2 border-dashed border-red-500/30">
                            <h3 className="text-lg font-bold text-red-500 dark:text-red-400 mb-2">Danger Zone</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                Deleting your account is permanent and cannot be undone. All your listings will be removed, and your data will be erased.
                            </p>
                            <button
                                onClick={handleDeleteAccount}
                                disabled={currentUser.role === 'admin'}
                                className="bg-red-600 text-white font-bold py-2 px-4 rounded-md hover:bg-red-700 transition-colors duration-300 disabled:bg-red-400/50 disabled:cursor-not-allowed"
                                title={currentUser.role === 'admin' ? "Admin account cannot be deleted from here for security." : "Delete Account"}
                            >
                                Delete My Account
                            </button>
                        </div>
                    </div>
                )}

                {activeTab === 'listings' && (
                    <div>
                        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">My Listings</h2>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                    <tr>
                                        <th scope="col" className="px-4 py-3">Service</th>
                                        <th scope="col" className="px-4 py-3">Username</th>
                                        <th scope="col" className="px-4 py-3">Price</th>
                                        <th scope="col" className="px-4 py-3">Status</th>
                                        <th scope="col" className="px-4 py-3 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {listings.map(listing => (
                                        <tr key={listing.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                            <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{listing.serviceName}</td>
                                            <td className="px-4 py-3">@{listing.username}</td>
                                            <td className="px-4 py-3 font-semibold text-brand-cyan">₦{listing.price.toLocaleString()}</td>
                                            <td className="px-4 py-3">
                                                <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Available</span>
                                            </td>
                                            <td className="px-4 py-3 text-right">
                                                <button 
                                                    onClick={() => onDeleteListing(listing.id)}
                                                    className="bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800/50 text-xs font-bold py-1 px-3 rounded-md transition-colors"
                                                    title="Delete listing"
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {listings.length === 0 && (
                                <div className="text-center py-12">
                                    <p className="text-gray-500 dark:text-gray-400">You haven't listed any accounts yet.</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {activeTab === 'purchases' && (
                     <div>
                        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Purchase History</h2>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                    <tr>
                                        <th scope="col" className="px-4 py-3">Date</th>
                                        <th scope="col" className="px-4 py-3">Service</th>
                                        <th scope="col" className="px-4 py-3">Username</th>
                                        <th scope="col" className="px-4 py-3">Password</th>
                                        <th scope="col" className="px-4 py-3">Status</th>
                                        <th scope="col" className="px-4 py-3">Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {purchases.map(item => (
                                        <tr key={item.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                            <td className="px-4 py-3 whitespace-nowrap">{new Date(item.purchaseDate).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{item.listing.serviceName}</td>
                                            <td className="px-4 py-3">@{item.listing.username}</td>
                                            <td className="px-4 py-3 font-mono text-gray-600 dark:text-gray-300">
                                                {item.status === PurchaseStatus.Completed ? item.listing.password : 'Hidden'}
                                            </td>
                                            <td className="px-4 py-3">
                                                 <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(item.status)}`}>{item.status}</span>
                                            </td>
                                            <td className="px-4 py-3 font-semibold text-red-500">-₦{item.listing.price.toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {purchases.length === 0 && (
                                <div className="text-center py-12">
                                    <p className="text-gray-500 dark:text-gray-400">You haven't purchased any accounts yet.</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                
                {activeTab === 'funding' && (
                    <div>
                        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Funding History</h2>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                    <tr>
                                        <th scope="col" className="px-4 py-3">Date</th>
                                        <th scope="col" className="px-4 py-3">Amount</th>
                                        <th scope="col" className="px-4 py-3">Status</th>
                                        <th scope="col" className="px-4 py-3">Reference</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {payments.map(tx => (
                                        <tr key={tx.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                            <td className="px-4 py-3 whitespace-nowrap">{new Date(tx.date).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-semibold text-green-600 dark:text-green-400">
                                                +₦{tx.amount.toLocaleString()}
                                            </td>
                                            <td className="px-4 py-3">
                                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(tx.status)}`}>{tx.status}</span>
                                            </td>
                                            <td className="px-4 py-3 text-gray-400 dark:text-gray-500 font-mono text-xs">{tx.reference}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {payments.length === 0 && (
                                <div className="text-center py-12">
                                    <p className="text-gray-500 dark:text-gray-400">No funding transactions recorded yet.</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MyAccountPanel;