import React from 'react';
import { MoonIcon, SunIcon, UserIcon } from './IconComponents';
import { User } from '../types';

interface HeaderProps {
    theme: 'dark' | 'light';
    toggleTheme: () => void;
    currentUser: User | null;
    onOpenAuthModal: () => void;
    onOpenFundWalletModal: () => void;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, toggleTheme, currentUser, onOpenAuthModal, onOpenFundWalletModal, onLogout }) => {
  return (
    <header className="bg-white/80 dark:bg-brand-light-dark/50 backdrop-blur-sm sticky top-0 z-10 border-b border-gray-200 dark:border-brand-slate/50">
      <div className="container mx-auto px-4 py-4 md:px-8">
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold tracking-wider text-gray-900 dark:text-white">
            HAYWHY<span className="text-brand-cyan">PLUGS</span>
          </div>
          <div className="flex items-center gap-4">
            {currentUser ? (
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 bg-gray-100 dark:bg-brand-slate/50 px-3 py-1.5 rounded-full">
                         <span className="text-gray-600 dark:text-gray-300 hidden sm:block"><UserIcon /></span>
                         <span className="font-medium text-gray-700 dark:text-gray-200 text-sm">Welcome, {currentUser.username}!</span>
                         <span className="w-px h-5 bg-gray-300 dark:bg-brand-slate mx-1"></span>
                         <span className="font-semibold text-gray-800 dark:text-white text-sm">₦{currentUser.walletBalance.toLocaleString()}</span>
                    </div>
                    <button
                        onClick={onOpenFundWalletModal}
                        className="flex items-center gap-2 bg-green-500 text-white font-bold py-1.5 px-3 rounded-full hover:bg-green-600 transition-colors text-sm"
                        aria-label="Fund wallet"
                        title="Fund Wallet"
                    >
                        <span>💰</span>
                        <span className="hidden sm:inline">Fund Wallet</span>
                    </button>
                    <button
                        onClick={onLogout}
                        className="font-semibold text-brand-cyan hover:text-cyan-600 dark:hover:text-white transition-colors"
                    >
                        Logout
                    </button>
                </div>
            ) : (
                 <button
                    onClick={onOpenAuthModal}
                    className="bg-brand-cyan text-brand-dark font-bold py-2 px-4 rounded-md hover:bg-cyan-400 transition-colors duration-300"
                >
                    Login / Sign Up
                </button>
            )}
            <button
                onClick={toggleTheme}
                className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors"
                aria-label="Toggle theme"
            >
                {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;