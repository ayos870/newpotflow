
import React, { useState, useMemo } from 'react';
import { Listing, SiteUser } from '../types';
import { CloseIcon } from './IconComponents';

interface MarkAsSoldModalProps {
  listing: Listing;
  users: SiteUser[];
  onClose: () => void;
  onConfirm: (listingId: string, buyerId: string) => void;
}

const MarkAsSoldModal: React.FC<MarkAsSoldModalProps> = ({ listing, users, onClose, onConfirm }) => {
  const [selectedBuyerId, setSelectedBuyerId] = useState('');

  const potentialBuyers = useMemo(() => {
    return users.filter(u => u.username !== listing.sellerUsername);
  }, [users, listing.sellerUsername]);

  const selectedBuyer = useMemo(() => {
    return users.find(u => u.id === selectedBuyerId);
  }, [users, selectedBuyerId]);
  
  const hasSufficientFunds = selectedBuyer ? selectedBuyer.walletBalance >= listing.price : false;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedBuyerId && hasSufficientFunds) {
      onConfirm(listing.id, selectedBuyerId);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-white dark:bg-brand-light-dark rounded-lg shadow-2xl w-full max-w-md m-auto relative animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors"
          aria-label="Close modal"
        >
          <CloseIcon />
        </button>
        <div className="p-8">
          <h2 className="text-2xl font-bold text-center mb-2 text-gray-900 dark:text-white">Mark Account as Sold</h2>
          <p className="text-center text-gray-500 dark:text-gray-400 mb-6">
            Manually assign <strong className="text-gray-800 dark:text-gray-100">@{listing.username}</strong> to a buyer. The price of <strong className="text-gray-800 dark:text-gray-100">₦{listing.price.toLocaleString()}</strong> will be deducted from their wallet.
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="buyer" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Select Buyer</label>
              <select
                id="buyer"
                value={selectedBuyerId}
                onChange={(e) => setSelectedBuyerId(e.target.value)}
                className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
              >
                <option value="" disabled>-- Select a user --</option>
                {potentialBuyers.map(user => (
                  <option key={user.id} value={user.id}>
                    {user.username} (Wallet: ₦{user.walletBalance.toLocaleString()})
                  </option>
                ))}
              </select>
            </div>
            {selectedBuyer && !hasSufficientFunds && (
              <p className="text-red-500 dark:text-red-400 text-sm text-center">
                This user has insufficient funds to purchase this account.
              </p>
            )}
            <div className="flex gap-4 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2.5 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!selectedBuyerId || !hasSufficientFunds}
                className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-300"
              >
                Confirm Sale
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default MarkAsSoldModal;