import React, { useState, useMemo } from 'react';
import { SiteUser, Listing, User, Payment, PurchaseStatus, PaymentSettings, SaleLog, AccountPurchase, Announcement } from '../types';
import { TrashIcon, UsersIcon, ClipboardListIcon, CheckCircleIcon, CashIcon, ShoppingCartIcon, BanIcon, CheckBadgeIcon, ClockIcon, XCircleIcon, PlusCircleIcon, WrenchIcon, ReceiptIcon, TagIcon, BellIcon } from './IconComponents';
import PaymentSettingsPanel from './PaymentSettingsPanel';
import { ListingForm } from './ListingForm';

interface AdminPanelProps {
    users: SiteUser[];
    listings: Listing[];
    payments: Payment[];
    salesLogs: SaleLog[];
    currentUser: User;
    paymentSettings: PaymentSettings;
    announcement: Announcement | null;
    onDeleteUser: (id: string) => void;
    onDeleteListing: (id: string) => void;
    onOpenMarkAsSoldModal: (listing: Listing) => void;
    onToggleUserBan: (userId: string) => void;
    onUpdatePaymentStatus: (paymentId: string, status: PurchaseStatus) => void;
    onOpenAdminFundUserModal: (user: SiteUser) => void;
    onUpdatePaymentSettings: (settings: PaymentSettings) => void;
    onAddListing: (account: Omit<Listing, 'id' | 'sellerUsername' | 'status'>) => void;
    onSetAnnouncement: (message: string) => void;
    onClearAnnouncement: () => void;
}

type AdminTab = 'users' | 'listings' | 'payments' | 'sales' | 'addListing' | 'settings' | 'announcements';

const StatCard: React.FC<{ icon: React.ReactNode, title: string, value: string | number, color: string }> = ({ icon, title, value, color }) => (
    <div className="bg-gray-50 dark:bg-brand-slate/50 p-4 rounded-lg flex items-center gap-4 border-l-4" style={{ borderColor: color }}>
        <div className="p-3 rounded-full bg-gray-200 dark:bg-brand-slate">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
        </div>
    </div>
);

const AnnouncementForm: React.FC<{ onSetAnnouncement: (message: string) => void; }> = ({ onSetAnnouncement }) => {
    const [message, setMessage] = useState('');
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (message.trim()) {
            onSetAnnouncement(message.trim());
            setMessage('');
        }
    };
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="announcement-msg" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">New Announcement Message</label>
                <textarea
                    id="announcement-msg"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={3}
                    className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    placeholder="Enter your message here..."
                />
            </div>
            <button
                type="submit"
                disabled={!message.trim()}
                className="inline-flex items-center gap-2 bg-brand-cyan text-brand-dark font-bold py-2.5 px-6 rounded-md hover:bg-cyan-400 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300"
            >
                Broadcast Announcement
            </button>
        </form>
    );
};


const AdminPanel: React.FC<AdminPanelProps> = ({ users, listings, payments, salesLogs, currentUser, paymentSettings, announcement, onDeleteUser, onDeleteListing, onOpenMarkAsSoldModal, onToggleUserBan, onUpdatePaymentStatus, onOpenAdminFundUserModal, onUpdatePaymentSettings, onAddListing, onSetAnnouncement, onClearAnnouncement }) => {
    const [activeTab, setActiveTab] = useState<AdminTab>('users');

    const stats = useMemo(() => {
        const totalEarnings = salesLogs.reduce((acc, log) => acc + log.price, 0);
        const totalListingValue = listings.filter(l => l.status === 'available').reduce((acc, listing) => acc + listing.price, 0);

        return {
            totalUsers: users.length,
            availableListings: listings.filter(l => l.status === 'available').length,
            soldAccounts: salesLogs.length,
            totalEarnings,
            totalListingValue,
        };
    }, [users, listings, payments, salesLogs]);

    const TabButton: React.FC<{ tab: AdminTab, label: string, count?: number, icon?: React.ReactNode }> = ({ tab, label, count, icon }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-bold transition-colors rounded-t-lg flex items-center gap-2 ${
                activeTab === tab
                ? 'text-brand-cyan border-b-2 border-brand-cyan'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
            }`}
        >
            {icon}
            {label}
            {typeof count !== 'undefined' && (
                <span className={`px-2 py-0.5 rounded-full text-xs ${activeTab === tab ? 'bg-brand-cyan text-brand-dark' : 'bg-gray-200 dark:bg-brand-slate text-gray-600 dark:text-gray-300'}`}>{count}</span>
            )}
        </button>
    );

    const getStatusBadge = (status: string) => {
        switch(status) {
            case 'Active': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
            case 'Banned': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
            case PurchaseStatus.Completed: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
            case PurchaseStatus.Pending: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
            case PurchaseStatus.Failed: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
        }
    }

    return (
        <div className="bg-white dark:bg-brand-light-dark p-6 rounded-lg shadow-2xl border border-gray-200 dark:border-brand-slate space-y-8">
            <div>
                <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Admin Dashboard</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                     <StatCard icon={<UsersIcon className="w-6 h-6 text-blue-500" />} title="Total Users" value={stats.totalUsers} color="#3b82f6"/>
                     <StatCard icon={<ClipboardListIcon className="w-6 h-6 text-purple-500" />} title="Available Listings" value={stats.availableListings} color="#8b5cf6"/>
                     <StatCard icon={<CheckCircleIcon className="w-6 h-6 text-green-500" />} title="Accounts Sold" value={stats.soldAccounts} color="#22c55e"/>
                     <StatCard icon={<CashIcon className="w-6 h-6 text-yellow-500" />} title="Total Earnings" value={`₦${stats.totalEarnings.toLocaleString()}`} color="#eab308"/>
                     <StatCard icon={<TagIcon className="w-6 h-6 text-indigo-500" />} title="Total Listing Value" value={`₦${stats.totalListingValue.toLocaleString()}`} color="#6366f1"/>
                </div>
            </div>

            <div>
                <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Management</h3>
                <div className="flex border-b-2 border-gray-200 dark:border-brand-slate mb-6 flex-wrap">
                    <TabButton tab="users" label="Users" count={users.length} />
                    <TabButton tab="listings" label="Listings" count={listings.length} />
                    <TabButton tab="payments" label="Payments" count={payments.length} />
                    <TabButton tab="sales" label="Sales Logs" count={salesLogs.length} />
                    <TabButton tab="addListing" label="Add Listing" />
                    <TabButton tab="announcements" label="Announcements" icon={<BellIcon className="w-5 h-5"/>}/>
                    <TabButton tab="settings" label="Settings" />
                </div>

                {activeTab === 'users' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                <tr>
                                    <th scope="col" className="px-4 py-3">User</th>
                                    <th scope="col" className="px-4 py-3">Wallet</th>
                                    <th scope="col" className="px-4 py-3">Status</th>
                                    <th scope="col" className="px-4 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map(user => (
                                    <tr key={user.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                        <td className="px-4 py-3">
                                            <div className="font-medium text-gray-900 dark:text-white">{user.username} {user.role === 'admin' && <span className="text-xs font-medium bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200 px-2 py-0.5 rounded-full ml-1">Admin</span>}</div>
                                            <div className="text-gray-500 dark:text-gray-400">{user.email}</div>
                                        </td>
                                        <td className="px-4 py-3 font-semibold">₦{user.walletBalance.toLocaleString()}</td>
                                        <td className="px-4 py-3">
                                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(user.banned ? 'Banned' : 'Active')}`}>{user.banned ? 'Banned' : 'Active'}</span>
                                        </td>
                                        <td className="px-4 py-3 flex items-center justify-end gap-2">
                                            <button
                                                onClick={() => onOpenAdminFundUserModal(user)}
                                                disabled={user.role === 'admin'}
                                                className="p-2 rounded-full text-gray-400 hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/50 dark:hover:text-blue-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                                title={user.role === 'admin' ? "Cannot fund an admin account" : "Fund User Wallet"}
                                            >
                                                <PlusCircleIcon className="w-5 h-5"/>
                                            </button>
                                            <button
                                                onClick={() => {
                                                    const action = user.banned ? 'unban' : 'ban';
                                                    if(window.confirm(`Are you sure you want to ${action} ${user.username}?`)) {
                                                        onToggleUserBan(user.id)
                                                    }
                                                }}
                                                disabled={user.username === currentUser.username}
                                                className={`p-2 rounded-full text-gray-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${user.banned ? 'hover:bg-green-100 hover:text-green-600 dark:hover:bg-green-900/50 dark:hover:text-green-400' : 'hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/50 dark:hover:text-red-400' }`}
                                                title={user.username === currentUser.username ? "Cannot moderate yourself" : (user.banned ? 'Unban User' : 'Ban User')}
                                            >
                                                {user.banned ? <CheckBadgeIcon className="w-5 h-5"/> : <BanIcon className="w-5 h-5"/>}
                                            </button>
                                            <button
                                                onClick={() => {
                                                    if (window.confirm(`Are you sure you want to delete user ${user.username}?`)) {
                                                        onDeleteUser(user.id);
                                                    }
                                                }}
                                                disabled={user.username === currentUser.username}
                                                className="p-2 rounded-full text-gray-400 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/50 dark:hover:text-red-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                                title={user.username === currentUser.username ? "Cannot delete yourself" : "Delete user"}
                                            >
                                                <TrashIcon className="w-5 h-5" />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                {activeTab === 'listings' && (
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                <tr>
                                    <th scope="col" className="px-4 py-3">Service</th>
                                    <th scope="col" className="px-4 py-3">Username</th>
                                    <th scope="col" className="px-4 py-3">Listed By</th>
                                    <th scope="col" className="px-4 py-3">Price</th>
                                    <th scope="col" className="px-4 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {listings.map(listing => (
                                    <tr key={listing.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                        <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{listing.serviceName}</td>
                                        <td className="px-4 py-3">@{listing.username}</td>
                                        <td className="px-4 py-3">{listing.sellerUsername}</td>
                                        <td className="px-4 py-3 font-semibold text-brand-cyan">₦{listing.price.toLocaleString()}</td>
                                        <td className="px-4 py-3 flex items-center justify-end gap-2">
                                            <button onClick={() => onOpenMarkAsSoldModal(listing)} className="p-2 rounded-full text-gray-400 hover:bg-green-100 hover:text-green-600 dark:hover:bg-green-900/50 dark:hover:text-green-400 transition-colors" title="Mark as sold">
                                                <ShoppingCartIcon className="w-5 h-5" />
                                            </button>
                                            <button onClick={() => onDeleteListing(listing.id)} className="bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800/50 text-xs font-bold py-1 px-3 rounded-md transition-colors" title="Delete listing">
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {listings.length === 0 && ( <div className="text-center py-12"><p className="text-gray-500 dark:text-gray-400">There are no active listings.</p></div> )}
                    </div>
                )}
                 {activeTab === 'payments' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                <tr>
                                    <th scope="col" className="px-4 py-3">User</th>
                                    <th scope="col" className="px-4 py-3">Amount</th>
                                    <th scope="col" className="px-4 py-3">Date</th>
                                    <th scope="col" className="px-4 py-3">Status</th>
                                    <th scope="col" className="px-4 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {payments.map(payment => (
                                    <tr key={payment.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                        <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{payment.username}</td>
                                        <td className="px-4 py-3 font-semibold">₦{payment.amount.toLocaleString()}</td>
                                        <td className="px-4 py-3">{new Date(payment.date).toLocaleString()}</td>
                                        <td className="px-4 py-3"><span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(payment.status)}`}>{payment.status}</span></td>
                                        <td className="px-4 py-3 flex items-center justify-end gap-2">
                                            {payment.status === PurchaseStatus.Pending ? (
                                                <>
                                                <button onClick={() => onUpdatePaymentStatus(payment.id, PurchaseStatus.Completed)} className="p-2 rounded-full text-gray-400 hover:bg-green-100 hover:text-green-600 dark:hover:bg-green-900/50 dark:hover:text-green-400 transition-colors" title="Mark Completed"><CheckCircleIcon className="w-5 h-5"/></button>
                                                <button onClick={() => onUpdatePaymentStatus(payment.id, PurchaseStatus.Failed)} className="p-2 rounded-full text-gray-400 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/50 dark:hover:text-red-400 transition-colors" title="Mark Failed"><XCircleIcon className="w-5 h-5"/></button>
                                                </>
                                            ) : <span className="text-xs text-gray-400 dark:text-gray-500 italic pr-2">Processed</span>}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                         {payments.length === 0 && ( <div className="text-center py-12"><p className="text-gray-500 dark:text-gray-400">No payment records found.</p></div> )}
                    </div>
                )}
                {activeTab === 'sales' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-brand-slate dark:text-gray-300">
                                <tr>
                                    <th scope="col" className="px-4 py-3">Date</th>
                                    <th scope="col" className="px-4 py-3">Service</th>
                                    <th scope="col" className="px-4 py-3">Seller</th>
                                    <th scope="col" className="px-4 py-3">Buyer</th>
                                    <th scope="col" className="px-4 py-3">Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {salesLogs.map(log => (
                                    <tr key={log.id} className="bg-white dark:bg-brand-light-dark border-b dark:border-brand-slate">
                                        <td className="px-4 py-3">{new Date(log.date).toLocaleString()}</td>
                                        <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{log.serviceName} <span className="text-gray-400 text-xs">(@{log.accountUsername})</span></td>
                                        <td className="px-4 py-3">{log.sellerUsername}</td>
                                        <td className="px-4 py-3">{log.buyerUsername}</td>
                                        <td className="px-4 py-3 font-semibold text-brand-cyan">₦{log.price.toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {salesLogs.length === 0 && ( <div className="text-center py-12"><p className="text-gray-500 dark:text-gray-400">No sales have been recorded yet.</p></div> )}
                    </div>
                )}
                 {activeTab === 'addListing' && (
                    <div>
                        <ListingForm onAddListing={onAddListing} />
                    </div>
                 )}
                {activeTab === 'announcements' && (
                    <div className="space-y-6">
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Site-Wide Announcements</h3>
                        {announcement && announcement.isActive ? (
                            <div className="bg-blue-50 dark:bg-blue-900/50 p-4 rounded-lg space-y-3">
                                <p className="text-sm font-medium text-blue-800 dark:text-blue-200">Current Announcement:</p>
                                <p className="text-blue-900 dark:text-blue-100">{announcement.message}</p>
                                <button
                                    onClick={onClearAnnouncement}
                                    className="bg-red-500 text-white font-bold py-2 px-4 rounded-md hover:bg-red-600 transition-colors text-sm"
                                >
                                    Clear Announcement
                                </button>
                            </div>
                        ) : (
                            <p className="text-gray-500 dark:text-gray-400">There is no active announcement.</p>
                        )}
                        <AnnouncementForm onSetAnnouncement={onSetAnnouncement} />
                    </div>
                )}
                {activeTab === 'settings' && (
                    <PaymentSettingsPanel 
                        settings={paymentSettings}
                        onUpdateSettings={onUpdatePaymentSettings}
                    />
                )}
            </div>
        </div>
    );
};

export default AdminPanel;