
import React, { useState } from 'react';
import { CloseIcon, KeyIcon } from './IconComponents';

interface AuthModalProps {
  onClose: () => void;
  onLogin: (credentials: { email: string; password?: string; rememberMe: boolean }) => string | void | undefined;
  onRegister: (credentials: { username: string; email: string; password?: string }) => string | void | undefined;
  onForgotPassword: (email: string) => string | void | undefined;
  onResetPassword: (details: { email: string; code: string; newPassword: string }) => string | void | undefined;
}

type AuthView = 'login' | 'register' | 'forgot' | 'reset';

const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLogin, onRegister, onForgotPassword, onResetPassword }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [view, setView] = useState<AuthView>('login');
  
  const clearFormState = () => {
    setUsername('');
    setEmail('');
    setPassword('');
    setCode('');
    setNewPassword('');
    setError('');
  }

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    let errorMsg;
    switch(view) {
        case 'login':
            errorMsg = onLogin({ email, password, rememberMe });
            if (errorMsg) setError(errorMsg);
            break;
        case 'register':
            errorMsg = onRegister({ username, email, password });
            if (errorMsg) setError(errorMsg);
            break;
        case 'forgot':
            errorMsg = onForgotPassword(email);
            if (errorMsg) {
                setError(errorMsg);
            } else {
                setView('reset');
            }
            break;
        case 'reset':
            errorMsg = onResetPassword({ email, code, newPassword });
            if (errorMsg && !errorMsg.startsWith('Success!')) {
                setError(errorMsg);
            } else {
                setSuccessMessage(errorMsg || "Password reset successfully.");
                setView('login');
                clearFormState();
            }
            break;
    }
  };
  
  const TabButton: React.FC<{ tab: 'login' | 'register'; label: string }> = ({ tab, label }) => (
    <button
      onClick={() => {
        setView(tab);
        clearFormState();
        setSuccessMessage('');
      }}
      className={`w-1/2 pb-2 font-bold transition-colors ${
        (view === 'login' || view === 'register') && view === tab
          ? 'text-brand-cyan border-b-2 border-brand-cyan'
          : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
      }`}
    >
      {label}
    </button>
  );


  const renderContent = () => {
    switch(view) {
        case 'reset':
            return (
                 <>
                    <h2 className="text-2xl font-bold text-center mb-1 text-gray-900 dark:text-white">Set New Password</h2>
                    <p className="text-center text-gray-500 dark:text-gray-400 mb-6">A reset code was "sent" to your email. Enter it below to update your password.</p>
                    <form onSubmit={handleAuth} className="space-y-4">
                        <div>
                            <label htmlFor="email-reset" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Email</label>
                            <input id="email-reset" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@example.com" required autoComplete="email"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                        <div>
                            <label htmlFor="code-reset" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Reset Code</label>
                             <input id="code-reset" type="text" value={code} onChange={(e) => setCode(e.target.value)}
                            placeholder="Enter the 6-digit code" required autoComplete="one-time-code"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 text-center">Hint: For this demo, the code is <strong className="font-mono">123456</strong></p>
                        </div>
                         <div>
                            <label htmlFor="new-password-reset" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">New Password</label>
                             <input id="new-password-reset" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="••••••••" required autoComplete="new-password"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                        {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                        <button type="submit" className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 transition-all duration-300 mt-2">
                            Reset Password
                        </button>
                         <button type="button" onClick={() => setView('login')} className="w-full text-center text-sm text-gray-500 dark:text-gray-400 hover:underline pt-2">
                            Back to Login
                        </button>
                    </form>
                </>
            )
        case 'forgot':
            return (
                <>
                    <h2 className="text-2xl font-bold text-center mb-1 text-gray-900 dark:text-white">Reset Password</h2>
                    <p className="text-center text-gray-500 dark:text-gray-400 mb-6">Enter your email to receive a reset code.</p>
                    <form onSubmit={handleAuth} className="space-y-4">
                        <div>
                            <label htmlFor="email-auth" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Email</label>
                            <input
                            id="email-auth" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@example.com" required autoComplete="email"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                        {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                        <button type="submit" className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 transition-all duration-300 mt-2">
                            Send Reset Code
                        </button>
                         <button type="button" onClick={() => setView('login')} className="w-full text-center text-sm text-gray-500 dark:text-gray-400 hover:underline pt-2">
                            Back to Login
                        </button>
                    </form>
                </>
            )
        case 'login':
        case 'register':
        default:
            return (
                <>
                    <div className="flex mb-6">
                        <TabButton tab="login" label="Login" />
                        <TabButton tab="register" label="Register" />
                    </div>

                    <h2 className="text-2xl font-bold text-center mb-1 text-gray-900 dark:text-white">
                        {view === 'login' ? 'Welcome Back' : 'Create Your Account'}
                    </h2>
                    <p className="text-center text-gray-500 dark:text-gray-400 mb-6">
                        {view === 'login' ? 'Sign in to continue' : 'to start selling today'}
                    </p>

                    <form onSubmit={handleAuth} className="space-y-4">
                        {successMessage && <p className="text-green-600 dark:text-green-400 text-sm text-center bg-green-100 dark:bg-green-900/50 p-3 rounded-md">{successMessage}</p>}
                        {view === 'register' && (
                            <div>
                                <label htmlFor="username-auth" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Username</label>
                                <input id="username-auth" type="text" value={username} onChange={(e) => setUsername(e.target.value)}
                                placeholder="Choose a username" required autoComplete="username"
                                className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                                />
                            </div>
                        )}
                        <div>
                            <label htmlFor="email-auth" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Email</label>
                            <input id="email-auth" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@example.com" required autoComplete="email"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                        <div>
                            <label htmlFor="password-auth" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Password</label>
                            <input id="password-auth" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••" required autoComplete={view === 'login' ? 'current-password' : 'new-password'}
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                         {view === 'login' && (
                           <div className="flex items-center justify-between">
                                <label className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={rememberMe}
                                        onChange={(e) => setRememberMe(e.target.checked)}
                                        className="h-4 w-4 rounded border-gray-300 dark:border-gray-600 text-brand-cyan focus:ring-brand-cyan bg-gray-100 dark:bg-brand-slate"
                                    />
                                    <span>Remember me</span>
                                </label>
                                <button type="button" onClick={() => { setView('forgot'); clearFormState(); setSuccessMessage(''); }} className="text-xs text-brand-cyan hover:underline">Forgot Password?</button>
                           </div>
                        )}
                        {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                        <button
                            type="submit"
                            className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 transition-all duration-300 mt-2"
                        >
                            {view === 'login' ? 'Login' : 'Create Account'}
                        </button>
                    </form>
                </>
            )
    }
  }


  return (
    <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
        aria-modal="true"
        role="dialog"
    >
      <div 
        className="bg-white dark:bg-brand-light-dark rounded-lg shadow-2xl w-full max-w-md m-auto relative animate-fade-in-up"
        onClick={e => e.stopPropagation()}
      >
        <button
            onClick={onClose}
            className="absolute top-3 right-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors"
            aria-label="Close authentication modal"
        >
            <CloseIcon />
        </button>

        <div className="p-8">
            {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
