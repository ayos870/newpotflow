import React, { useState, useEffect } from 'react';
import { PaymentSettings, PaymentProvider } from '../types';
import { SaveIcon } from './IconComponents';

interface PaymentSettingsPanelProps {
    settings: PaymentSettings;
    onUpdateSettings: (settings: PaymentSettings) => void;
}

const PaymentSettingsPanel: React.FC<PaymentSettingsPanelProps> = ({ settings, onUpdateSettings }) => {
    const [localSettings, setLocalSettings] = useState<PaymentSettings>(settings);
    const [successMessage, setSuccessMessage] = useState('');

    useEffect(() => {
        setLocalSettings(settings);
    }, [settings]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        
        // Use `as any` to handle dynamic key assignment for properties with specific types like 'provider' and 'environment'.
        let newSettings: PaymentSettings = { ...localSettings, [name]: value as any };

        // When provider changes, clear specific keys
        if (name === 'provider') {
            const { encryptionKey, contractCode, ...rest } = newSettings;
            if (value === PaymentProvider.Flutterwave) {
                newSettings = { ...rest, provider: value, encryptionKey: settings.encryptionKey || '' };
            } else if (value === PaymentProvider.Monnify) {
                 newSettings = { ...rest, provider: value, contractCode: settings.contractCode || '' };
            } else {
                // FIX: Cast string value from select input to PaymentProvider to satisfy TypeScript type checking.
                newSettings = { ...rest, provider: value as PaymentProvider };
            }
        }
        
        setLocalSettings(newSettings);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const finalSettings = { ...localSettings };
        if (finalSettings.provider !== PaymentProvider.Flutterwave) {
            delete finalSettings.encryptionKey;
        }
        if (finalSettings.provider !== PaymentProvider.Monnify) {
            delete finalSettings.contractCode;
        }
        onUpdateSettings(finalSettings);
        setSuccessMessage('Settings saved successfully!');
        setTimeout(() => setSuccessMessage(''), 3000);
    };

    const providerName = localSettings.provider.charAt(0).toUpperCase() + localSettings.provider.slice(1);

    const getPublicKeyLabel = () => {
        switch(localSettings.provider) {
            case PaymentProvider.Opay: return 'Merchant ID';
            case PaymentProvider.Monnify: return 'API Key';
            default: return 'Public Key';
        }
    };

    return (
        <div className="space-y-6">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Payment Gateway Settings</h3>
            <form onSubmit={handleSubmit} className="space-y-4 max-w-xl">
                <div>
                    <label htmlFor="provider" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Payment Provider</label>
                    <select
                        id="provider"
                        name="provider"
                        value={localSettings.provider}
                        onChange={handleChange}
                        className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    >
                        <option value={PaymentProvider.Paystack}>Paystack</option>
                        <option value={PaymentProvider.Flutterwave}>Flutterwave</option>
                        <option value={PaymentProvider.Opay}>OPay</option>
                        <option value={PaymentProvider.Monnify}>Monnify</option>
                    </select>
                </div>
                 <div>
                    <label htmlFor="environment" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Environment</label>
                    <select
                        id="environment"
                        name="environment"
                        value={localSettings.environment || 'sandbox'}
                        onChange={handleChange}
                        className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    >
                        <option value="sandbox">Sandbox</option>
                        <option value="live">Live</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="publicKey" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">
                      {getPublicKeyLabel()}
                    </label>
                    <input
                        id="publicKey"
                        name="publicKey"
                        type="text"
                        value={localSettings.publicKey}
                        onChange={handleChange}
                        placeholder={`Enter ${providerName} ${getPublicKeyLabel()}`}
                        required
                        className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    />
                </div>
                <div>
                    <label htmlFor="secretKey" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Secret Key</label>
                    <input
                        id="secretKey"
                        name="secretKey"
                        type="password"
                        value={localSettings.secretKey}
                        onChange={handleChange}
                        placeholder={`Enter ${providerName} Secret Key`}
                        required
                        className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    />
                </div>
                
                {localSettings.provider === PaymentProvider.Flutterwave && (
                    <div>
                        <label htmlFor="encryptionKey" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Encryption Key</label>
                        <input
                            id="encryptionKey"
                            name="encryptionKey"
                            type="password"
                            value={localSettings.encryptionKey || ''}
                            onChange={handleChange}
                            placeholder="Enter Flutterwave Encryption Key"
                            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                        />
                    </div>
                )}

                {localSettings.provider === PaymentProvider.Monnify && (
                    <>
                        <div>
                            <label htmlFor="contractCode" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Contract Code</label>
                            <input
                                id="contractCode"
                                name="contractCode"
                                type="text"
                                value={localSettings.contractCode || ''}
                                onChange={handleChange}
                                placeholder="Enter Monnify Contract Code"
                                required
                                className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                            />
                        </div>
                        {(localSettings.environment === 'live') ? (
                             <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">Contract Code is required for the 'Live' environment.</p>
                        ) : (
                             <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">You can use a default/placeholder contract code for the 'Sandbox' environment.</p>
                        )}
                    </>
                )}
                
                {successMessage && <p className="text-green-500 dark:text-green-400 text-sm">{successMessage}</p>}

                <div className="pt-2">
                    <button type="submit" className="inline-flex items-center gap-2 bg-brand-cyan text-brand-dark font-bold py-2.5 px-6 rounded-md hover:bg-cyan-400 transition-all duration-300">
                        <SaveIcon className="w-5 h-5" />
                        Save Settings
                    </button>
                </div>
            </form>

            {localSettings.provider === PaymentProvider.Opay && (
                    <div className="mt-4 p-4 bg-gray-100 dark:bg-brand-slate/50 rounded-lg border border-dashed border-gray-300 dark:border-brand-slate max-w-xl">
                        <h4 className="font-bold text-md text-gray-800 dark:text-gray-200">Webhook Configuration</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            For OPay payments to be automatically confirmed, your backend server must handle webhook notifications.
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                            Please set the following URL in your OPay merchant dashboard:
                        </p>
                        <code className="block bg-gray-200 dark:bg-brand-dark text-gray-700 dark:text-gray-300 p-2 rounded-md text-xs mt-2 font-mono">
                            https://[your-backend-domain]/opay/webhook
                        </code>
                    </div>
            )}
            {localSettings.provider === PaymentProvider.Monnify && (
                    <div className="mt-4 p-4 bg-gray-100 dark:bg-brand-slate/50 rounded-lg border border-dashed border-gray-300 dark:border-brand-slate max-w-xl">
                        <h4 className="font-bold text-md text-gray-800 dark:text-gray-200">Webhook Configuration</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            For Monnify payments to be automatically confirmed, your backend server must handle webhook notifications.
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                            Please set the following URL in your Monnify merchant dashboard:
                        </p>
                        <code className="block bg-gray-200 dark:bg-brand-dark text-gray-700 dark:text-gray-300 p-2 rounded-md text-xs mt-2 font-mono">
                            https://[your-backend-domain]/monnify/webhook
                        </code>
                    </div>
            )}
        </div>
    );
};

export default PaymentSettingsPanel;
