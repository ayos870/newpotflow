import React, { useState } from 'react';
import { Listing, User } from '../types';
import { CloseIcon, CubeIcon } from './IconComponents';

interface AccountDetailModalProps {
  account: Listing;
  onClose: () => void;
  onPurchase: (account: Listing) => void;
  currentUser: User | null;
}

const AccountDetailModal: React.FC<AccountDetailModalProps> = ({ account, onClose, onPurchase, currentUser }) => {
  const [error, setError] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  if (!account) return null;

  const handlePurchaseClick = () => {
    setError('');
    if (!currentUser) {
        setError('You must be logged in to purchase an account.');
        return;
    }
    if (currentUser.walletBalance < account.price) {
        setError('Insufficient funds. Please fund your wallet to complete this purchase.');
        return;
    }
    setShowConfirmation(true);
  };
  
  const handleConfirmPurchase = () => {
    onPurchase(account);
    setShowConfirmation(false);
  }

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-white dark:bg-brand-light-dark rounded-lg shadow-2xl w-full max-w-lg m-auto relative animate-fade-in-up flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-200 dark:border-brand-slate flex justify-between items-start">
            <div className="flex items-center gap-4">
                <span className="w-16 h-16 flex items-center justify-center bg-gray-100 dark:bg-brand-slate rounded-full text-brand-cyan">
                    <CubeIcon className="w-8 h-8" />
                </span>
                <div>
                    <p className="text-md text-gray-500 dark:text-gray-400">{account.serviceName}</p>
                    <h2 className="text-3xl font-bold text-gray-900 dark:text-white">@{account.username}</h2>
                </div>
            </div>
            <button
                onClick={onClose}
                className="p-1 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors"
                aria-label="Close account details modal"
            >
                <CloseIcon />
            </button>
        </div>

        <div className="p-6 flex-grow overflow-y-auto">
          <div className="bg-gray-50 dark:bg-brand-slate/50 p-4 rounded-lg text-center">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Price</p>
              <p className="text-3xl font-bold text-brand-cyan">₦{account.price.toLocaleString()}</p>
          </div>
        </div>

        <div className="p-6 bg-gray-50 dark:bg-brand-slate/30 border-t border-gray-200 dark:border-brand-slate/50 rounded-b-lg">
          {error && <p className="text-red-500 dark:text-red-400 text-sm text-center mb-4">{error}</p>}
          <button 
            onClick={handlePurchaseClick}
            disabled={!currentUser}
            className="w-full bg-brand-cyan text-brand-dark font-bold py-3 px-4 rounded-md hover:bg-cyan-400 transition-colors duration-300 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:text-gray-500 disabled:cursor-not-allowed"
          >
            Purchase Account
          </button>
        </div>

        {showConfirmation && (
            <div className="absolute inset-0 bg-white/80 dark:bg-brand-light-dark/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 rounded-lg animate-fade-in">
                <h3 className="text-xl font-bold text-center mb-2 text-gray-900 dark:text-white">Confirm Purchase</h3>
                <p className="text-center text-gray-600 dark:text-gray-300 mb-6">
                    The purchase amount of <strong className="text-gray-800 dark:text-gray-100">₦{account.price.toLocaleString()}</strong> will be deducted from your wallet, and account credentials will be available immediately in your "My Account" area.
                </p>
                <div className="flex gap-4 w-full max-w-xs">
                    <button
                        onClick={() => setShowConfirmation(false)}
                        className="w-full bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2.5 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleConfirmPurchase}
                        className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 transition-all duration-300"
                    >
                        Yes, Confirm
                    </button>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default AccountDetailModal;