import React from 'react';
import { ArrowLeftIcon } from './IconComponents';

interface TermsOfServiceProps {
  onBack: () => void;
}

const TermsOfService: React.FC<TermsOfServiceProps> = ({ onBack }) => {
  return (
    <div className="container mx-auto p-4 md:p-8 animate-fade-in">
      <div className="bg-white dark:bg-brand-light-dark p-8 rounded-lg shadow-2xl border border-gray-200 dark:border-brand-slate">
        <div className="flex justify-between items-center mb-6 border-b-2 border-gray-200 dark:border-brand-slate pb-4">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Terms of Service</h1>
          <button
            onClick={onBack}
            className="flex items-center gap-2 bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            Back to Marketplace
          </button>
        </div>

        <div className="prose prose-lg dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 space-y-4">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <p>Welcome to HAYWHY PLUGS! These terms and conditions outline the rules and regulations for the use of our website and services.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">1. User Accounts</h2>
          <p>When you create an account with us, you must provide information that is accurate, complete, and current at all times. You are responsible for safeguarding the password that you use to access the service and for any activities or actions under your password.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">2. Account Listings</h2>
          <p>By listing an account for sale, you affirm that you are the legitimate owner of the account and have the right to transfer it. All information provided in a listing must be accurate and not misleading. We reserve the right to remove any listing that violates our policies.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">3. Transactions and Payments</h2>
          <p>All purchases are processed through our secure escrow system. When a buyer initiates a purchase, the funds are held by us until an administrator manually approves the transaction. Upon approval, the funds are released to the seller, and the account credentials are made available to the buyer. If a transaction is rejected, the funds are returned to the buyer, and the account is re-listed.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">4. Prohibited Conduct</h2>
          <p>You agree not to engage in any of the following prohibited activities: (i) using the service for any illegal purpose or in violation of any local, state, national, or international law; (ii) selling fraudulent or stolen accounts; (iii) harassing, threatening, or defrauding other users; (iv) interfering with the proper working of the Service.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">5. Limitation of Liability</h2>
          <p>In no event shall HAYWHY PLUGS, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.</p>

          <h2 className="text-xl font-bold text-gray-900 dark:text-white">6. Changes to Terms</h2>
          <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms of Service on this page.</p>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;