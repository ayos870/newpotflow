
import React, { useState } from 'react';
import { Listing } from '../types';

interface ListingFormProps {
  onAddListing: (account: Omit<Listing, 'id' | 'sellerUsername' | 'status'>) => void;
}

export const ListingForm: React.FC<ListingFormProps> = ({ onAddListing }) => {
  const [serviceName, setServiceName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState('');

  const canSubmit = serviceName.trim() !== '' && username.trim() !== '' && password.trim() !== '' && parseInt(price) > 0;

  const resetForm = () => {
    setServiceName('');
    setUsername('');
    setPassword('');
    setPrice('');
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;

    onAddListing({
      serviceName,
      username,
      password,
      price: parseInt(price),
    });

    resetForm();
  };

  return (
    <div className="bg-white dark:bg-brand-light-dark p-6 rounded-lg shadow-2xl border border-gray-200 dark:border-brand-slate relative">
      <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">List Your Account</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="serviceName" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Service Name</label>
          <input
            id="serviceName"
            type="text"
            value={serviceName}
            onChange={(e) => setServiceName(e.target.value)}
            placeholder="e.g., Premium Streaming Service"
            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
          />
        </div>
        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Username / Email</label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="user@example.com"
            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
          />
        </div>
        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
          />
        </div>
        <div>
            <label htmlFor="price" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Price (₦)</label>
            <input
            id="price"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="e.g., 1500"
            className="w-full bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
            />
        </div>

        {error && <p className="text-red-500 dark:text-red-400 text-sm">{error}</p>}
        <div className="flex gap-4 pt-2">
             <button
                type="button"
                onClick={resetForm}
                className="w-full bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2.5 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
            >
                Cancel
            </button>
            <button
                type="submit"
                disabled={!canSubmit}
                className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-300"
            >
                List Account
            </button>
        </div>
      </form>
    </div>
  );
};