
import React, { useState } from 'react';
import { SiteUser } from '../types';
import { CloseIcon } from './IconComponents';

interface AdminFundUserModalProps {
  user: SiteUser;
  onClose: () => void;
  onConfirm: (userId: string, amount: number) => void;
}

const AdminFundUserModal: React.FC<AdminFundUserModalProps> = ({ user, onClose, onConfirm }) => {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid positive amount.');
      return;
    }
    setError('');
    onConfirm(user.id, numericAmount);
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-white dark:bg-brand-light-dark rounded-lg shadow-2xl w-full max-w-sm m-auto relative animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors"
          aria-label="Close modal"
        >
          <CloseIcon />
        </button>
        <div className="p-8">
          <h2 className="text-2xl font-bold text-center mb-2 text-gray-900 dark:text-white">Fund User Wallet</h2>
          <p className="text-center text-gray-500 dark:text-gray-400 mb-6">
            Add funds directly to <strong className="text-gray-800 dark:text-gray-100">{user.username}</strong>'s wallet.
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="fund-amount" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Amount to Add (₦)</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 dark:text-gray-500">₦</span>
                    <input
                        id="fund-amount"
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="e.g., 10000"
                        required
                        min="1"
                        step="1"
                        className="w-full pl-7 bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                    />
                </div>
            </div>
            {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
            <div className="flex gap-4 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2.5 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!amount || parseFloat(amount) <= 0}
                className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-300"
              >
                Confirm Funding
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminFundUserModal;
