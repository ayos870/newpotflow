
import React from 'react';
import { Listing, User } from '../types';
import { CubeIcon } from './IconComponents';

interface AccountCardProps {
  account: Listing;
  onViewDetails: (account: Listing) => void;
  currentUser: User | null;
  isOwner?: boolean;
}

const AccountCard: React.FC<AccountCardProps> = ({ account, onViewDetails, currentUser, isOwner = false }) => {
  const { serviceName, username, price } = account;

  return (
    <div className="bg-white dark:bg-brand-light-dark rounded-lg overflow-hidden border border-gray-200 dark:border-brand-slate shadow-lg hover:shadow-cyan-500/10 dark:hover:shadow-cyan-500/20 hover:border-brand-cyan/50 transition-all duration-300 flex flex-col relative">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 flex items-center justify-center bg-gray-100 dark:bg-brand-slate rounded-full text-brand-cyan">
                <CubeIcon className="w-6 h-6"/>
            </span>
            <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{serviceName}</p>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white">@{username}</h3>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold text-brand-cyan">₦{price.toLocaleString()}</p>
          </div>
        </div>
        
        <div className="h-4"></div>

      </div>
      <div className="p-4 bg-gray-50 dark:bg-brand-slate/30 border-t border-gray-200 dark:border-brand-slate/50">
        <button 
          onClick={() => onViewDetails(account)}
          disabled={isOwner || !currentUser}
          className="w-full bg-brand-cyan text-brand-dark font-bold py-2 px-4 rounded-md hover:bg-cyan-400 transition-colors duration-300 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:text-gray-500 disabled:cursor-not-allowed">
          {isOwner ? 'Your Listing' : 'Purchase'}
        </button>
      </div>
    </div>
  );
};

export default AccountCard;