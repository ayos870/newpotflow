
import React, { useState } from 'react';
import { CloseIcon, PaystackIcon, FlutterwaveIcon, OpayIcon, MonnifyIcon } from './IconComponents';
import { PaymentSettings, PaymentProvider } from '../types';

interface FundWalletModalProps {
  onClose: () => void;
  onFund: (amount: number, reference: string) => void;
  paymentSettings: PaymentSettings;
  userEmail: string;
}

const FundWalletModal: React.FC<FundWalletModalProps> = ({ onClose, onFund, paymentSettings, userEmail }) => {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSimulatingRedirect, setIsSimulatingRedirect] = useState(false);
  
  const handlePayment = () => {
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid amount greater than zero.');
      return;
    }
    setError('');
    setIsLoading(true);

    if (paymentSettings.provider === PaymentProvider.Paystack) {
      handlePaystackPayment(numericAmount);
    } else if (paymentSettings.provider === PaymentProvider.Flutterwave) {
      handleFlutterwavePayment(numericAmount);
    } else if (paymentSettings.provider === PaymentProvider.Opay) {
      handleOpayPayment(numericAmount);
    } else if (paymentSettings.provider === PaymentProvider.Monnify) {
      handleMonnifyPayment(numericAmount);
    }
  };

  const handlePaystackPayment = (numericAmount: number) => {
    const handler = (window as any).PaystackPop.setup({
      key: paymentSettings.publicKey,
      email: userEmail, 
      amount: numericAmount * 100, // Paystack expects amount in kobo
      currency: 'NGN',
      ref: 'SSW_PSTK_' + Math.floor((Math.random() * 1000000000) + 1),
      onClose: () => {
        setIsLoading(false);
      },
      callback: (response: any) => {
        setIsLoading(false);
        onFund(numericAmount, response.reference);
      },
    });
    handler.openIframe();
  };

  const handleFlutterwavePayment = (numericAmount: number) => {
    (window as any).FlutterwaveCheckout({
      public_key: paymentSettings.publicKey,
      tx_ref: "SSW_FLW_" + Date.now(),
      amount: numericAmount,
      currency: "NGN",
      payment_options: "card, banktransfer, ussd",
      customer: {
        email: userEmail,
      },
      customizations: {
        title: "HAYWHY PLUGS Wallet Funding",
        description: `Payment of ₦${numericAmount} to your wallet`,
      },
      callback: function (response: any) {
         if (response.status === "successful") {
            onFund(numericAmount, response.tx_ref);
         } else {
            console.log("Flutterwave payment not successful: ", response);
            alert("Payment was not successful.");
         }
         setIsLoading(false);
      },
      onclose: function() {
        setIsLoading(false);
      },
    });
  }
  
  const handleOpayPayment = (numericAmount: number) => {
    // Simulate a server-side redirect flow for OPay.
    console.log('Initiating OPay payment by calling backend...');
    setIsSimulatingRedirect(true);
    setTimeout(() => {
      // In a real app, the user would be redirected. 
      // After payment, a webhook would notify our backend to fund the wallet.
      // Here, we simulate that completion.
      onFund(numericAmount, `SSW_OPAY_${Date.now()}`);
    }, 2500);
  };

  const handleMonnifyPayment = (numericAmount: number) => {
    const environment = paymentSettings.environment || 'sandbox';
    const apiUrl = environment === 'live' 
        ? "https://api.monnify.com/api/v1/merchant/transactions/init-transaction" 
        : "https://sandbox.monnify.com/api/v1/merchant/transactions/init-transaction";

    console.log(`Initiating Monnify payment in ${environment} mode...`);
    console.log(`Calling backend to create transaction at: ${apiUrl}`);
    
    setIsSimulatingRedirect(true);
    setTimeout(() => {
      onFund(numericAmount, `SSW_MONNIFY_${Date.now()}`);
    }, 2500);
  };

  const renderPaymentButton = () => {
    const commonClasses = "w-full flex items-center justify-center gap-2 text-white font-bold py-2.5 px-4 rounded-md hover:bg-opacity-90 transition-all duration-300 disabled:bg-gray-300 dark:disabled:bg-brand-slate disabled:cursor-not-allowed";
    
    if (isLoading) {
        return (
            <button
                type="button"
                disabled
                className={`${commonClasses} bg-gray-500`}
            >
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                Processing...
            </button>
        );
    }
    
    let buttonContent;
    let buttonClass;
    
    switch(paymentSettings.provider) {
        case PaymentProvider.Paystack:
            buttonContent = <><PaystackIcon className="w-5 h-5" fill="#fff" /> Pay with Paystack</>;
            buttonClass = 'bg-[#011b33]';
            break;
        case PaymentProvider.Flutterwave:
            buttonContent = <><FlutterwaveIcon className="w-5 h-5" /> Pay with Flutterwave</>;
            buttonClass = 'bg-[#f5a623]';
            break;
        case PaymentProvider.Opay:
            buttonContent = <><OpayIcon className="w-5 h-5" fill="white"/> Pay with OPay</>;
            buttonClass = 'bg-[#20C058]';
            break;
        case PaymentProvider.Monnify:
            buttonContent = <><MonnifyIcon className="w-5 h-5" /> Pay with Monnify</>;
            buttonClass = 'bg-[#4A6A81]';
            break;
        default:
            buttonContent = <>Pay Now</>;
            buttonClass = 'bg-brand-cyan';
    }

    return (
        <button
            type="button"
            onClick={handlePayment}
            disabled={!amount || parseFloat(amount) <= 0}
            className={`${commonClasses} ${buttonClass}`}
        >
            {buttonContent}
        </button>
    );
  }


  return (
    <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
        aria-modal="true"
        role="dialog"
    >
      <div 
        className="bg-white dark:bg-brand-light-dark rounded-lg shadow-2xl w-full max-w-sm m-auto relative animate-fade-in-up"
        onClick={e => e.stopPropagation()}
      >
        <button
            onClick={onClose}
            className="absolute top-3 right-3 p-1 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-brand-slate transition-colors z-20"
            aria-label="Close funding modal"
        >
            <CloseIcon />
        </button>

        <div className="p-8">
            <h2 className="text-2xl font-bold text-center mb-2 text-gray-900 dark:text-white">
                Fund Your Wallet
            </h2>
            <p className="text-center text-gray-500 dark:text-gray-400 mb-6">
                Add funds securely with our payment partner.
            </p>

            <div className="space-y-4">
                <div>
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Amount (₦)</label>
                    <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 dark:text-gray-500">₦</span>
                        <input
                            id="amount"
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="e.g., 50000"
                            required
                            min="1"
                            step="1"
                            className="w-full pl-7 bg-gray-50 dark:bg-brand-slate border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-cyan"
                        />
                    </div>
                </div>
                {error && <p className="text-red-500 dark:text-red-400 text-sm text-center">{error}</p>}
                <div className="pt-2">
                    {renderPaymentButton()}
                </div>
                 <p className="text-xs text-center text-gray-400 dark:text-gray-500 pt-2">
                    Payments are securely processed by <span className="font-semibold capitalize">{paymentSettings.provider}</span>.
                 </p>
            </div>
        </div>

        {isSimulatingRedirect && (
            <div className="absolute inset-0 bg-white/90 dark:bg-brand-light-dark/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 rounded-lg animate-fade-in z-10">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-cyan mb-4"></div>
                <h3 className="text-lg font-bold text-center text-gray-900 dark:text-white">Connecting to Secure Payment Gateway...</h3>
                <p className="text-center text-gray-600 dark:text-gray-300 mt-2">
                    Please wait while we redirect you.
                </p>
            </div>
        )}

      </div>
    </div>
  );
};

export default FundWalletModal;