
import React, { useState, useMemo, useEffect } from 'react';
import { Listing, SiteUser, Payment, PurchaseStatus, PaymentSettings, PaymentProvider, SaleLog, Notification as NotificationType, AccountPurchase, Announcement } from './types';
import Header from './components/Header';
import { ListingForm } from './components/ListingForm';
import AccountCard from './components/AccountCard';
import AuthModal from './components/AuthModal';
import AccountDetailModal from './components/AccountDetailModal';
import FundWalletModal from './components/FundWalletModal';
import Footer from './components/Footer';
import AdminPanel from './components/AdminPanel';
import MyAccountPanel from './components/MyAccountPanel';
import MarkAsSoldModal from './components/MarkAsSoldModal';
import AdminFundUserModal from './components/AdminFundUserModal';
import NotificationContainer from './components/Notification';
import { ShieldIcon, CogIcon, ArrowRightIcon } from './components/IconComponents';
import TermsOfService from './components/TermsOfService';
import AllListingsPage from './components/AllListingsPage';
import AnnouncementBanner from './components/AnnouncementBanner';

// Initial mock data to populate the UI
const initialListings: Listing[] = [
  {
    id: '1',
    serviceName: 'Premium Streaming Service',
    username: 'user@example.com',
    password: 'strongPassword123',
    price: 1500,
    sellerUsername: 'admin',
    status: 'available',
  },
  {
    id: '2',
    serviceName: 'Pro Design Software',
    username: 'designer_pro',
    password: 'design!pass',
    price: 12000,
    sellerUsername: 'admin',
    status: 'available',
  },
  {
    id: '3',
    serviceName: 'VPN Yearly Subscription',
    username: 'secure_user',
    password: 'vpn_is_life',
    price: 25000,
    sellerUsername: 'admin',
    status: 'available',
  },
   {
    id: '4',
    serviceName: 'Cloud Storage 2TB Plan',
    username: 'storage_king',
    password: 'cloudypassword',
    price: 8000,
    sellerUsername: 'admin',
    status: 'available',
  },
  {
    id: '5',
    serviceName: 'Online Gaming Account',
    username: 'pro_gamer_hd',
    password: 'gameon123',
    price: 35000,
    sellerUsername: 'admin',
    status: 'available',
  },
];

const initialUsers: SiteUser[] = [
  { id: 'u0', email: 'aransiolayomide30@gmail.com', username: 'admin', password: 'ayomide12@', walletBalance: 9999999, role: 'admin', banned: false },
  { id: 'u1', email: 'jane@example.com', username: 'janedoe', password: 'password123', walletBalance: 150000, role: 'user', banned: false },
  { id: 'u2', email: 'socialswapper@example.com', username: 'socialswapper', password: 'password123', walletBalance: 75000, role: 'user', banned: false },
];

const initialPayments: Payment[] = [
    { id: 'p1', userId: 'u1', username: 'janedoe', amount: 50000, status: PurchaseStatus.Completed, date: new Date(Date.now() - 86400000).toISOString(), reference: 'PSTK_581335' },
    { id: 'p2', userId: 'u2', username: 'socialswapper', amount: 25000, status: PurchaseStatus.Pending, date: new Date().toISOString(), reference: 'PSTK_991245' },
    { id: 'p3', userId: 'u1', username: 'janedoe', amount: 10000, status: PurchaseStatus.Failed, date: new Date(Date.now() - 172800000).toISOString(), reference: 'PSTK_725091' },
];

type ActiveTab = 'available' | 'myAccount' | 'adminPanel';
type CurrentView = 'marketplace' | 'terms' | 'allListings';

const App: React.FC = () => {
  const [listings, setListings] = useState<Listing[]>(initialListings);
  const [users, setUsers] = useState<SiteUser[]>(initialUsers);
  const [payments, setPayments] = useState<Payment[]>(initialPayments);
  const [salesLogs, setSalesLogs] = useState<SaleLog[]>([]);
  const [accountPurchases, setAccountPurchases] = useState<AccountPurchase[]>([]);
  const [notifications, setNotifications] = useState<NotificationType[]>([]);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [currentUser, setCurrentUser] = useState<SiteUser | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Listing | null>(null);
  const [showFundWalletModal, setShowFundWalletModal] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('available');
  const [showMarkAsSoldModal, setShowMarkAsSoldModal] = useState(false);
  const [listingToMarkSold, setListingToMarkSold] = useState<Listing | null>(null);
  const [showAdminFundUserModal, setShowAdminFundUserModal] = useState(false);
  const [userToFund, setUserToFund] = useState<SiteUser | null>(null);
  const [currentView, setCurrentView] = useState<CurrentView>('marketplace');
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>({
    provider: PaymentProvider.Opay,
    publicKey: "YOUR_OPAY_MERCHANT_ID",
    secretKey: "YOUR_OPAY_SECRET_KEY",
    environment: 'sandbox',
  });
  const [announcement, setAnnouncement] = useState<Announcement | null>(null);
  const [announcementDismissed, setAnnouncementDismissed] = useState(false);

  useEffect(() => {
    // Check for a saved user session on initial app load
    const savedUserId = localStorage.getItem('haywhyPlugsUser');
    if (savedUserId) {
      const foundUser = users.find(u => u.id === savedUserId);
      if (foundUser && !foundUser.banned) {
        setCurrentUser(foundUser);
        addNotification(`Welcome back, ${foundUser.username}!`, 'success');
      } else {
        localStorage.removeItem('haywhyPlugsUser');
      }
    }
  }, []); // Empty dependency array ensures this runs only once on mount

  useEffect(() => {
    if (currentUser && announcement && announcement.isActive && !announcementDismissed) {
      const timer = setTimeout(() => {
        addNotification(`Announcement: ${announcement.message}`, 'info');
      }, 1500); // Delay slightly after login message
      return () => clearTimeout(timer);
    }
  }, [currentUser, announcement, announcementDismissed]);

  useEffect(() => {
    // Enforce admin-only access to the admin panel view, similar to backend middleware.
    if (activeTab === 'adminPanel' && currentUser?.role !== 'admin') {
      setActiveTab('available');
    }
  }, [activeTab, currentUser]);

  const addNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
        removeNotification(id);
    }, 5000);
  };

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleLogin = (creds: { email: string; password?: string; rememberMe: boolean }): string | void => {
    const { email, password, rememberMe } = creds;
    const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (!foundUser) {
        return "Account not found. Please register.";
    }
    if (foundUser.password !== password) {
        return "Invalid password.";
    }
    if (foundUser.banned) {
        addNotification("Your account has been suspended. Please contact support.", "error");
        return;
    }
    
    setCurrentUser(foundUser);
    setShowAuthModal(false);
    setActiveTab('available');
    addNotification(`Welcome back, ${foundUser.username}!`, 'success');

    if (rememberMe) {
        localStorage.setItem('haywhyPlugsUser', foundUser.id);
    } else {
        localStorage.removeItem('haywhyPlugsUser');
    }
  };

  const handleRegister = (creds: { username: string; email: string; password?: string }): string | void => {
    const { username, email, password } = creds;

    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        return "An account with this email already exists.";
    }
    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
        return "This username is already taken.";
    }
    if (!password) {
        return "Password is required.";
    }

    const newUser: SiteUser = {
        id: `u${Date.now()}`,
        email,
        username,
        password,
        walletBalance: 0,
        role: 'user',
        banned: false,
    };

    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    setShowAuthModal(false);
    setActiveTab('available');
    addNotification('Account created successfully! Welcome to HAYWHY PLUGS.', 'success');
  };
  
  const handleForgotPassword = (email: string): string | void => {
    const userExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
    if (!userExists) {
      return "No account found with that email address.";
    }
    console.log(`Password reset initiated for ${email}. Mock code is 123456.`);
  };

  const handleResetPassword = (details: { email: string; code: string; newPassword: string }): string | void => {
    const { email, code, newPassword } = details;
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (!user) {
      return "No account found with that email address.";
    }
    if (code !== '123456') {
      return "Invalid reset code.";
    }

    setUsers(prevUsers =>
      prevUsers.map(u => (u.id === user.id ? { ...u, password: newPassword } : u))
    );
    
    return "Success! Your password has been reset. Please log in.";
  };

  const handleLogout = () => {
    addNotification(`You have been logged out.`, 'info');
    setCurrentUser(null);
    setActiveTab('available');
    localStorage.removeItem('haywhyPlugsUser');
  };
  const handleOpenAuthModal = () => setShowAuthModal(true);
  const handleCloseAuthModal = () => setShowAuthModal(false);

  const handleFundWallet = (amount: number, reference: string) => {
    if (!currentUser) return;

    setShowFundWalletModal(false);
    
    const newPayment: Payment = {
        id: `p${Date.now()}`,
        userId: currentUser.id,
        username: currentUser.username,
        amount,
        status: PurchaseStatus.Pending,
        date: new Date().toISOString(),
        reference,
    };
    setPayments(prev => [newPayment, ...prev]);
    
    addNotification(`Funding request of ₦${amount.toLocaleString()} submitted for verification.`, 'info');

    setTimeout(() => {
        setPayments(prevPayments => 
            prevPayments.map(p => p.id === newPayment.id ? { ...p, status: PurchaseStatus.Completed } : p)
        );

        const updatedUser = { ...currentUser, walletBalance: currentUser.walletBalance + amount };
        
        setCurrentUser(updatedUser);
        setUsers(prevUsers => prevUsers.map(u => u.id === currentUser.id ? updatedUser : u));

        addNotification(`Your wallet has been funded with ₦${amount.toLocaleString()}.`, 'success');

    }, 3500);
  };

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    if (newTheme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  };

  const handleAddListing = (newListing: Omit<Listing, 'id' | 'sellerUsername' | 'status'>) => {
    if (!currentUser) return;
    const listing: Listing = {
      ...newListing,
      id: Date.now().toString(),
      sellerUsername: currentUser.username,
      status: 'available',
    };
    setListings(prevListings => [listing, ...prevListings]);
    addNotification(`Your account for ${listing.serviceName} has been listed successfully!`, 'success');
  };

  const handleViewDetails = (account: Listing) => {
    setSelectedAccount(account);
  };

  const handleCloseDetails = () => {
    setSelectedAccount(null);
  };

  const logSaleAndNotify = (account: Listing, buyer: SiteUser) => {
    // 1. Create Sale Log
    const newLog: SaleLog = {
      id: `sale-${Date.now()}`,
      date: new Date().toISOString(),
      listingId: account.id,
      accountUsername: account.username,
      serviceName: account.serviceName,
      price: account.price,
      sellerUsername: account.sellerUsername,
      buyerUsername: buyer.username,
    };
    setSalesLogs(prev => [newLog, ...prev]);

    // 2. Simulate Email Notification to Admin
    console.log(`
      --- [EMAIL SIMULATION] ---
      To: aransiolayomide30@gmail.com
      Subject: New Account Sale: @${account.username} for ${account.serviceName}

      A new sale has occurred on HAYWHY PLUGS.

      - Service: ${account.serviceName}
      - Account: @${account.username}
      - Price: ₦${account.price.toLocaleString()}
      - Sold by: ${account.sellerUsername}
      - Purchased by: ${buyer.username}
      - Date: ${new Date(newLog.date).toLocaleString()}
      --------------------------
    `);
    
    // 3. Notify Admin in real-time if they are logged in and not the buyer
    if (currentUser?.role === 'admin' && currentUser.id !== buyer.id) {
        addNotification(`New Sale: ${account.serviceName} account was sold to ${buyer.username}.`, 'info');
    }
  };

  const handlePurchase = (account: Listing) => {
    if (!currentUser || currentUser.username === account.sellerUsername) return;
    const seller = users.find(u => u.username === account.sellerUsername);
    if (!seller) {
        addNotification('Could not find seller for this listing.', 'error');
        return;
    }
    if (currentUser.walletBalance < account.price) {
        addNotification('Insufficient funds to complete this purchase.', 'error');
        return;
    }

    // --- Transaction Logic ---
    // 1. Update balances
    const updatedBuyer = { ...currentUser, walletBalance: currentUser.walletBalance - account.price };
    const updatedSeller = { ...seller, walletBalance: seller.walletBalance + account.price };

    setCurrentUser(updatedBuyer);
    setUsers(prevUsers => prevUsers.map(u => {
        if (u.id === updatedBuyer.id) return updatedBuyer;
        if (u.id === updatedSeller.id) return updatedSeller;
        return u;
    }));

    // 2. Update listing status to 'sold'
    setListings(prev => prev.map(l => l.id === account.id ? { ...l, status: 'sold' } : l));

    // 3. Create a completed purchase record
    const newPurchase: AccountPurchase = {
        id: `purch-${Date.now()}`,
        listing: { ...account, status: 'sold' },
        buyer: updatedBuyer,
        seller: updatedSeller,
        status: PurchaseStatus.Completed,
        purchaseDate: new Date().toISOString(),
    };
    setAccountPurchases(prev => [newPurchase, ...prev]);

    // 4. Log sale and notify
    logSaleAndNotify(account, updatedBuyer);
    addNotification(`Successfully purchased ${account.serviceName}! Credentials are in 'My Account'.`, 'success');

    // 5. Close modal
    handleCloseDetails();
  };

  const handleDeleteListing = (id: string) => {
    if(window.confirm('Are you sure you want to delete this listing? This action cannot be undone.')) {
      setListings(prev => prev.filter(l => l.id !== id));
      addNotification('Listing deleted successfully.', 'info');
    }
  };

  const handleDeleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };
  
  const handleDeleteCurrentUser = () => {
    if (!currentUser) return;
    
    const usernameToDelete = currentUser.username;
    
    // Remove user's listings
    setListings(prev => prev.filter(l => l.sellerUsername !== usernameToDelete));
    
    // Remove user
    setUsers(prev => prev.filter(u => u.id !== currentUser.id));

    // Logout and show notification
    addNotification('Your account has been permanently deleted.', 'info');
    handleLogout();
  };

  const handleOpenMarkAsSoldModal = (listing: Listing) => {
    setListingToMarkSold(listing);
    setShowMarkAsSoldModal(true);
  };
  
  const handleCloseMarkAsSoldModal = () => {
    setListingToMarkSold(null);
    setShowMarkAsSoldModal(false);
  };

  const handleMarkAsSold = (listingId: string, buyerId: string) => {
    const listing = listings.find(l => l.id === listingId);
    const buyer = users.find(u => u.id === buyerId);
    const seller = users.find(u => u.username === listing?.sellerUsername);

    if (!listing || !buyer || !seller) {
      addNotification('An error occurred. Listing, buyer, or seller not found.', 'error');
      return;
    }
    if (buyer.walletBalance < listing.price) {
      addNotification(`${buyer.username} has insufficient funds.`, 'error');
      return;
    }

    // Deduct from buyer
    const updatedBuyer = {...buyer, walletBalance: buyer.walletBalance - listing.price};
    // Add to seller
    const updatedSeller = {...seller, walletBalance: seller.walletBalance + listing.price};
    
    setUsers(prevUsers => prevUsers.map(u => {
        if (u.id === buyerId) return updatedBuyer;
        if (u.id === seller.id) return updatedSeller;
        return u;
    }));

    if (currentUser?.id === buyerId) setCurrentUser(updatedBuyer);
    
    setListings(prev => prev.map(l => l.id === listingId ? {...l, status: 'sold'} : l));
    
    const purchaseRecord: AccountPurchase = {
        id: `purch-manual-${Date.now()}`,
        listing,
        buyer: updatedBuyer,
        seller: updatedSeller,
        status: PurchaseStatus.Completed,
        purchaseDate: new Date().toISOString()
    };
    setAccountPurchases(prev => [purchaseRecord, ...prev]);

    logSaleAndNotify(listing, updatedBuyer);
    addNotification(`${listing.serviceName} has been marked as sold to ${buyer.username}.`, 'success');

    handleCloseMarkAsSoldModal();
  };

    const handleToggleUserBan = (userId: string) => {
        let action = '';
        setUsers(prevUsers =>
            prevUsers.map(user => {
                if (user.id === userId) {
                    action = !user.banned ? 'banned' : 'unbanned';
                    return { ...user, banned: !user.banned };
                }
                return user;
            })
        );
        const username = users.find(u => u.id === userId)?.username;
        if(username) addNotification(`${username} has been ${action}.`, 'info');
    };

    const handleUpdatePaymentStatus = (paymentId: string, newStatus: PurchaseStatus) => {
        const payment = payments.find(p => p.id === paymentId);
        if (!payment || payment.status !== PurchaseStatus.Pending) return;

        setPayments(prevPayments =>
            prevPayments.map(p => (p.id === paymentId ? { ...p, status: newStatus } : p))
        );

        if (newStatus === PurchaseStatus.Completed) {
            const userToUpdate = users.find(u => u.id === payment.userId);
            if (userToUpdate) {
                const updatedUser = { ...userToUpdate, walletBalance: userToUpdate.walletBalance + payment.amount };
                setUsers(prevUsers => prevUsers.map(u => u.id === payment.userId ? updatedUser : u));

                if (currentUser?.id === payment.userId) {
                    setCurrentUser(updatedUser);
                }
                 addNotification(`Payment approved. ${userToUpdate.username}'s wallet funded.`, 'success');
            }
        } else {
             addNotification(`Payment from ${payment.username} marked as failed.`, 'info');
        }
    };

  const handleOpenAdminFundUserModal = (user: SiteUser) => {
    setUserToFund(user);
    setShowAdminFundUserModal(true);
  };

  const handleCloseAdminFundUserModal = () => {
    setUserToFund(null);
    setShowAdminFundUserModal(false);
  };

  const handleAdminFundUserWallet = (userId: string, amount: number) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;
    
    const newPayment: Payment = {
        id: `p-admin-${Date.now()}`,
        userId: user.id,
        username: user.username,
        amount,
        status: PurchaseStatus.Completed,
        date: new Date().toISOString(),
        reference: `ADMIN_GRANT_${currentUser?.username.toUpperCase()}`
    };

    setPayments(prev => [newPayment, ...prev]);
    setUsers(prev => prev.map(u => u.id === userId ? {...u, walletBalance: u.walletBalance + amount} : u));
    
    if (currentUser?.id === userId) {
        setCurrentUser(prev => prev ? { ...prev, walletBalance: prev.walletBalance + amount } : null);
    }
    
    addNotification(`Successfully funded ${user.username}'s wallet with ₦${amount.toLocaleString()}.`, 'success');
    handleCloseAdminFundUserModal();
  };

  const handleUpdateUser = (updatedDetails: Partial<SiteUser>): string | void => {
    if (!currentUser) return;
  
    if (updatedDetails.username && users.some(u => u.id !== currentUser.id && u.username.toLowerCase() === updatedDetails.username?.toLowerCase())) {
      return "This username is already taken. Please choose another one.";
    }

    if (updatedDetails.email && users.some(u => u.id !== currentUser.id && u.email.toLowerCase() === updatedDetails.email?.toLowerCase())) {
      return "This email is already in use by another account.";
    }
  
    const updatedUser = { ...currentUser, ...updatedDetails };
  
    setCurrentUser(updatedUser);
    setUsers(prev => prev.map(u => (u.id === currentUser.id ? updatedUser : u)));
    
    if (updatedDetails.username) {
        setListings(prev => prev.map(l => l.sellerUsername === currentUser.username ? {...l, sellerUsername: updatedDetails.username!} : l));
    }

    addNotification('Your profile has been updated successfully!', 'success');
  };

  const handleUpdatePaymentSettings = (settings: PaymentSettings) => {
    setPaymentSettings(settings);
    addNotification('Payment gateway settings have been updated.', 'success');
  };

  const handleSetAnnouncement = (message: string) => {
    setAnnouncement({ message, isActive: true });
    setAnnouncementDismissed(false); // New announcement should be shown to everyone
    addNotification('Announcement has been broadcast site-wide.', 'success');
  };

  const handleClearAnnouncement = () => {
    setAnnouncement(null);
    addNotification('The site-wide announcement has been cleared.', 'info');
  };

  const handleShowTerms = () => setCurrentView('terms');
  const handleShowAllListings = () => setCurrentView('allListings');
  const handleShowMarketplace = () => setCurrentView('marketplace');

  const availableListings = useMemo(() => {
    return listings.filter(l => l.status === 'available');
  }, [listings]);

  const TabButton: React.FC<{ tab: ActiveTab; label: string; icon?: React.ReactNode }> = ({ tab, label, icon }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center gap-2 px-4 py-2 text-sm font-bold transition-colors rounded-t-lg ${
        activeTab === tab
          ? 'text-brand-cyan border-b-2 border-brand-cyan'
          : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  const renderCurrentView = () => {
    switch(currentView) {
      case 'terms':
        return <TermsOfService onBack={handleShowMarketplace} />;
      case 'allListings':
        return <AllListingsPage 
                  listings={availableListings} 
                  onBack={handleShowMarketplace}
                  onViewDetails={handleViewDetails}
                  currentUser={currentUser}
                />;
      case 'marketplace':
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-1 lg:sticky top-24">
              {currentUser?.role === 'admin' ? (
                <ListingForm onAddListing={handleAddListing} />
              ) : (
                <div className="bg-white dark:bg-brand-light-dark p-6 rounded-lg shadow-2xl border border-dashed border-gray-300 dark:border-brand-slate text-center">
                    <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">
                      {currentUser ? 'Admin-Only Feature' : 'Join the Marketplace'}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {currentUser ? 'Only administrators are permitted to list new accounts for sale.' : 'You need to be logged in to purchase an account.'}
                    </p>
                    {!currentUser && (
                        <button
                            onClick={handleOpenAuthModal}
                            className="w-full bg-brand-cyan text-brand-dark font-bold py-2.5 px-4 rounded-md hover:bg-cyan-400 transition-all duration-300"
                        >
                          Login / Sign Up
                        </button>
                    )}
                </div>
              )}
            </div>
            <div className="lg:col-span-2">
              {currentUser ? (
                <div className="flex border-b-2 border-gray-200 dark:border-brand-slate mb-6">
                  <TabButton tab="available" label="Available Accounts" />
                  <TabButton tab="myAccount" label="My Account" icon={<CogIcon className="w-5 h-5"/>} />
                   {currentUser.role === 'admin' && (
                    <TabButton tab="adminPanel" label="Admin Panel" icon={<ShieldIcon className="w-5 h-5"/>} />
                  )}
                </div>
              ) : (
                 <h2 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white border-b-2 border-gray-200 dark:border-brand-slate pb-2">Recently Added</h2>
              )}
              
              {activeTab === 'adminPanel' && currentUser?.role === 'admin' ? (
                <AdminPanel 
                  users={users}
                  listings={listings.filter(l => l.status !== 'sold')}
                  payments={payments}
                  salesLogs={salesLogs}
                  currentUser={currentUser}
                  paymentSettings={paymentSettings}
                  announcement={announcement}
                  onDeleteUser={handleDeleteUser}
                  onDeleteListing={handleDeleteListing}
                  onOpenMarkAsSoldModal={handleOpenMarkAsSoldModal}
                  onToggleUserBan={handleToggleUserBan}
                  onUpdatePaymentStatus={handleUpdatePaymentStatus}
                  onOpenAdminFundUserModal={handleOpenAdminFundUserModal}
                  onUpdatePaymentSettings={handleUpdatePaymentSettings}
                  onAddListing={handleAddListing}
                  onSetAnnouncement={handleSetAnnouncement}
                  onClearAnnouncement={handleClearAnnouncement}
                />
              ) : activeTab === 'myAccount' && currentUser ? (
                   <MyAccountPanel
                      currentUser={currentUser}
                      listings={listings.filter(l => l.sellerUsername === currentUser.username && l.status !== 'sold')}
                      payments={payments.filter(p => p.userId === currentUser.id)}
                      purchases={accountPurchases.filter(p => p.buyer.id === currentUser.id)}
                      onUpdateUser={handleUpdateUser}
                      onDeleteListing={handleDeleteListing}
                      onDeleteCurrentUser={handleDeleteCurrentUser}
                   />
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {availableListings.slice(0, 4).map(account => (
                      <AccountCard 
                        key={account.id} 
                        account={account} 
                        onViewDetails={handleViewDetails}
                        currentUser={currentUser}
                        isOwner={currentUser?.username === account.sellerUsername}
                      />
                    ))}
                  </div>
                  {availableListings.length === 0 && (
                      <div className="col-span-1 md:col-span-2 text-center py-12 bg-white dark:bg-brand-light-dark rounded-lg shadow-inner">
                          <p className="text-gray-500 dark:text-gray-400">
                              No accounts available at the moment.
                          </p>
                      </div>
                  )}
                  {availableListings.length > 4 && (
                      <div className="mt-8 text-center">
                          <button
                            onClick={handleShowAllListings}
                            className="inline-flex items-center gap-2 bg-gray-200 dark:bg-brand-slate text-gray-700 dark:text-gray-200 font-bold py-2.5 px-6 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-all duration-300"
                          >
                              See All Accounts
                              <ArrowRightIcon className="w-5 h-5"/>
                          </button>
                      </div>
                  )}
                </>
              )}
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-brand-dark text-gray-800 dark:text-gray-200 font-sans transition-colors duration-300 flex flex-col">
      {announcement && announcement.isActive && !announcementDismissed && (
        <AnnouncementBanner
          message={announcement.message}
          onDismiss={() => setAnnouncementDismissed(true)}
        />
      )}
      <NotificationContainer notifications={notifications} removeNotification={removeNotification} />
      <Header 
        theme={theme} 
        toggleTheme={toggleTheme} 
        currentUser={currentUser}
        onOpenAuthModal={handleOpenAuthModal}
        onOpenFundWalletModal={() => setShowFundWalletModal(true)}
        onLogout={handleLogout}
      />
      <main className="container mx-auto p-4 md:p-8 flex-grow">
        {renderCurrentView()}
      </main>
      <Footer onShowTerms={handleShowTerms} />
      {showAuthModal && (
        <AuthModal 
          onClose={handleCloseAuthModal} 
          onLogin={handleLogin} 
          onRegister={handleRegister}
          onForgotPassword={handleForgotPassword}
          onResetPassword={handleResetPassword}
        />
      )}
      {selectedAccount && (
        <AccountDetailModal 
            account={selectedAccount} 
            onClose={handleCloseDetails}
            onPurchase={handlePurchase}
            currentUser={currentUser}
        />
      )}
      {showFundWalletModal && currentUser && (
        <FundWalletModal
            onClose={() => setShowFundWalletModal(false)}
            onFund={handleFundWallet}
            paymentSettings={paymentSettings}
            userEmail={currentUser.email}
        />
      )}
      {showMarkAsSoldModal && listingToMarkSold && (
        <MarkAsSoldModal
            listing={listingToMarkSold}
            users={users}
            onClose={handleCloseMarkAsSoldModal}
            onConfirm={handleMarkAsSold}
        />
      )}
      {showAdminFundUserModal && userToFund && (
        <AdminFundUserModal
            user={userToFund}
            onClose={handleCloseAdminFundUserModal}
            onConfirm={handleAdminFundUserWallet}
        />
      )}
    </div>
  );
};

export default App;