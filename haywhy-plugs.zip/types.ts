export enum PurchaseStatus {
  Pending = 'Pending',
  Completed = 'Completed',
  Failed = 'Failed',
}

export enum PaymentProvider {
    Paystack = 'paystack',
    Flutterwave = 'flutterwave',
    Opay = 'opay',
    Monnify = 'monnify',
}

export interface PaymentSettings {
    provider: PaymentProvider;
    publicKey: string;
    secretKey: string;
    encryptionKey?: string;
    contractCode?: string;
    environment?: 'sandbox' | 'live';
}

export interface Payment {
  id: string;
  userId: string;
  username: string;
  amount: number;
  status: PurchaseStatus;
  date: string;
  reference?: string;
}

export interface Listing {
  id: string;
  serviceName: string;
  username: string;
  password: string;
  price: number;
  sellerUsername: string;
  status: 'available' | 'sold';
}

export interface AccountPurchase {
  id: string;
  listing: Listing;
  buyer: SiteUser;
  seller: SiteUser;
  status: PurchaseStatus;
  purchaseDate: string;
}

export interface User {
    username: string;
    walletBalance: number;
    role: 'user' | 'admin';
}

export interface SiteUser extends User {
    id: string;
    email: string;
    password: string;
    banned?: boolean;
}

export interface SaleLog {
  id: string;
  date: string;
  listingId: string;
  accountUsername: string;
  serviceName: string;
  price: number;
  sellerUsername: string;
  buyerUsername: string;
}

export interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

export interface Announcement {
  message: string;
  isActive: boolean;
}